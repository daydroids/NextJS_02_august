

const config={
    type: 'carousel',
    perView: 1,
    autoplay: 3000
};

new Glide('.glide', config).mount()

//  Breakpoints.match({
//     400: { perView: 1 },
//     600: { perView: 2 },
//     1200: { perView: 3 }
// }) 
